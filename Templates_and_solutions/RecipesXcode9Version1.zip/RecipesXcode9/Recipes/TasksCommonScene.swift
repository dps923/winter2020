//
//  TasksCommonScene.swift
//  Purpose - Common standard view controller tasks
//

//  ( more to come )

import UIKit

class TasksCommonScene: UIViewController {

    // MARK: - Instance variables
    
    // MARK: - Outlets (user interface)
    
    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
