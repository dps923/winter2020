//
//  ListBaseCD.swift
//  Purpose - Enables controllers with less code, by defining a common base class for all Core Data aware table view controllers; works with an extension
//

import UIKit

class ListBaseCD: UITableViewController {
    
    // Nothing added yet
}
