##  This is README.md in the template project

You can use this project as a 'template'. How?

In Finder, select this project's folder.
Command+D to duplicate.

Rename the folder to your desired new name.
Open the folder, then open the project file (which is still named "AppData.xcodeproj") in Xcode.

In the Project Navigator, select the project item (it has a blue icon).
Press the tab key, and type your desired new name.
You will be prompted through the rename procedure.

Then, on the Product menu, choose Scheme > Manage Schemes...
Click to select the (only) scheme, and press the tab key until it highlights the (old) scheme name.
Type the new scheme name, and press Enter (then Close on the dialog box)

Clean (Shift+Command+K), and then Build (Command+B).
