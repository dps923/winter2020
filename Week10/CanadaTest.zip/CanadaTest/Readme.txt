
This is Readme.txt in the CanadaTest project

It was built with the template.
