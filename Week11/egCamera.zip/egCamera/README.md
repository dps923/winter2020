#  Camera example

Shows the ability to use the device's *camera* or *photo library*. 

Code is in `ViewController.swift`.
Read its comments.

