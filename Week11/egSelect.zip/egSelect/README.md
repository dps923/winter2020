#  Select example

Shows the ability to use a list (table view) as an item-selection list.

Code is in a number of Swift source code files:
* DataModelManager
* ViewController
* ExampleSelectList

