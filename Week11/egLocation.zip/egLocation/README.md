#  Location example

Shows two capabilities:
1. Location services, to get and use a GPS coordinate set 
2. Reverse geocoding, to get and use the address for a GPS coordinate set

Code is in ViewController. swift.  
Read its comments.  
